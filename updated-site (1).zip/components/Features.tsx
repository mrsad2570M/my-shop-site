import React from 'react';

const featuresList = [
    "خرید امن و مطمئن با گارانتی",
    "فروش بدون دردسر و در کوتاه‌ترین زمان",
    "تنوع بالای محصولات دیجیتال",
    "مشاوره تخصصی برای خرید و فروش",
    "پشتیبانی کامل پس از فروش",
    "امکان تست حضوری کالا در اصفهان",
];

const Features: React.FC = () => {
    return (
        <section id="features" className="py-20 bg-gray-50">
            <div className="container mx-auto px-5">
                <div className="grid lg:grid-cols-2 gap-12 items-center">
                    <div className="order-2 lg:order-1">
                        <h2 className="text-4xl md:text-5xl font-extrabold mb-6 text-gray-800">چرا باید سایبان را انتخاب کنید؟</h2>
                        <p className="text-lg text-gray-600 mb-8">
                            ما فقط یک واسطه نیستیم؛ ما همراه شما در تمام مراحل هستیم. با تکیه بر تخصص و تجربه، بهترین شرایط را برای معامله شما فراهم می‌کنیم.
                        </p>
                        <ul className="space-y-4">
                            {featuresList.map((feature, index) => (
                                <li key={index} className="flex items-center text-lg">
                                    <span className="ml-4 text-2xl">✨</span>
                                    <span className="font-medium text-gray-700">{feature}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                    <div className="order-1 lg:order-2">
                        <div className="relative w-full h-80 lg:h-96 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl shadow-2xl flex items-center justify-center">
                             <div className="absolute text-8xl opacity-20">🛋️</div>
                             <img src="https://images.unsplash.com/photo-1524758631624-e2822e304c36?auto=format&fit=crop&w=400&h=300&q=80" alt="تصویری از کالاهای دست دوم با کیفیت مانند میز و صندلی" className="w-4/5 h-4/5 object-cover rounded-2xl shadow-lg transform rotate-3" />
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Features;