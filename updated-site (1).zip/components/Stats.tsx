
import React, { useState, useEffect, useRef } from 'react';

const CountUp: React.FC<{ end: number; duration?: number }> = ({ end, duration = 2000 }) => {
    const [count, setCount] = useState(0);
    const ref = useRef<HTMLSpanElement>(null);

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    let start = 0;
                    const startTime = performance.now();

                    const animateCount = (timestamp: number) => {
                        const progress = timestamp - startTime;
                        start = Math.min(end, Math.ceil(end * (progress / duration)));
                        setCount(start);

                        if (progress < duration) {
                            requestAnimationFrame(animateCount);
                        }
                    };

                    requestAnimationFrame(animateCount);
                    observer.disconnect();
                }
            },
            { threshold: 0.5 }
        );

        if (ref.current) {
            observer.observe(ref.current);
        }

        return () => observer.disconnect();
    }, [end, duration]);

    return <span ref={ref}>{count.toLocaleString('fa-IR')}</span>;
};


const stats = [
    { number: 500, label: "معامله موفق" },
    { number: 98, label: "رضایت مشتریان (%)" },
    { number: 1200, label: "کالای ثبت شده" },
    { number: 7, label: "روز میانگین فروش" },
];

const Stats: React.FC = () => {
    return (
        <section className="py-20 bg-gradient-to-r from-gray-800 to-gray-900 text-white">
            <div className="container mx-auto px-5">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                    {stats.map((stat, index) => (
                        <div key={index} className="p-4">
                            <h3 className="text-5xl md:text-6xl font-extrabold mb-2 bg-gradient-to-r from-pink-500 to-orange-400 bg-clip-text text-transparent">
                                <CountUp end={stat.number} />+
                            </h3>
                            <p className="text-lg text-gray-300">{stat.label}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Stats;
