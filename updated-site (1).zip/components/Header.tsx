import React, { useState, useEffect } from 'react';

const navLinks = [
    { title: "خدمات ما", href: "#services" },
    { title: "چرا ما؟", href: "#features" },
    { title: "نظرات مشتریان", href: "#testimonials" },
    { title: "تماس با ما", href: "#contact" },
];

const Header: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [isScrolled, setIsScrolled] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 10);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement | HTMLButtonElement>) => {
        if (e.currentTarget.tagName === 'A') {
            e.preventDefault();
            const href = e.currentTarget.getAttribute('href');
            if (href) {
                const targetElement = document.querySelector(href);
                if (targetElement) {
                    targetElement.scrollIntoView({ behavior: 'smooth' });
                }
            }
        }
        if (isOpen) {
            setIsOpen(false);
        }
    };

    return (
        <header className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white/95 backdrop-blur-sm shadow-md' : 'bg-transparent'}`}>
            <nav className="container mx-auto px-5 py-4 flex justify-between items-center">
                <a href="#" className="text-4xl font-extrabold bg-gradient-to-r from-indigo-500 to-purple-600 bg-clip-text text-transparent">
                    🏪
                    <span className="hidden sm:inline">سایبان</span>
                </a>
                <ul className="hidden md:flex items-center space-x-6 space-x-reverse">
                    {navLinks.map((link) => (
                        <li key={link.href}>
                            <a href={link.href} onClick={handleNavClick} className="text-gray-700 font-medium text-lg relative after:content-[''] after:absolute after:w-0 after:h-0.5 after:bottom-0 after:left-0 after:bg-gradient-to-r after:from-indigo-500 after:to-purple-600 after:transition-all after:duration-300 hover:after:w-full hover:text-indigo-500">
                                {link.title}
                            </a>
                        </li>
                    ))}
                     <li>
                        <a href="#register" onClick={handleNavClick} className="px-5 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-full font-semibold shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-300">
                            ورود / ثبت نام
                        </a>
                    </li>
                </ul>
                <div className="md:hidden">
                    <button onClick={() => setIsOpen(!isOpen)} className="text-gray-800 focus:outline-none">
                        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={isOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16m-7 6h7"}></path>
                        </svg>
                    </button>
                </div>
            </nav>
            {/* Mobile Menu */}
            <div className={`md:hidden fixed top-[72px] right-0 h-screen w-full bg-white/95 backdrop-blur-sm transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
                <ul className="flex flex-col items-center justify-center h-full space-y-8">
                    {navLinks.map((link) => (
                        <li key={link.href}>
                            <a href={link.href} onClick={handleNavClick} className="text-gray-700 text-2xl font-semibold">
                                {link.title}
                            </a>
                        </li>
                    ))}
                    <li>
                        <a href="#register" onClick={handleNavClick} className="px-8 py-4 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-full font-semibold text-xl shadow-lg">
                            ورود / ثبت نام
                        </a>
                    </li>
                </ul>
            </div>
        </header>
    );
};

export default Header;