import React from 'react';
import { WhatsAppIcon, PhoneIcon, DownloadIcon } from './Icons';

interface QuickActionsProps {
    onInstallClick: () => void;
    showInstallButton: boolean;
}

const QuickActions: React.FC<QuickActionsProps> = ({ onInstallClick, showInstallButton }) => {
    return (
        <div className="fixed bottom-5 left-5 z-40 flex flex-col gap-3">
            {showInstallButton && (
                <button
                    onClick={onInstallClick}
                    className="w-14 h-14 rounded-full flex items-center justify-center text-white shadow-lg transform hover:scale-110 transition-transform duration-300 bg-indigo-500"
                    aria-label="نصب اپلیکیشن"
                    title="نصب اپلیکیشن"
                >
                    <DownloadIcon />
                </button>
            )}
            <a href="https://wa.me/989139330651" target="_blank" rel="noopener noreferrer" className="w-14 h-14 rounded-full flex items-center justify-center text-white shadow-lg transform hover:scale-110 transition-transform duration-300 bg-green-500">
                <WhatsAppIcon />
            </a>
            <a href="tel:+989139330651" className="w-14 h-14 rounded-full flex items-center justify-center text-white shadow-lg transform hover:scale-110 transition-transform duration-300 bg-blue-500">
                <PhoneIcon />
            </a>
        </div>
    );
};

export default QuickActions;