
import React from 'react';

const testimonials = [
    {
        quote: "فروش لپ‌تاپم از طریق سایبان خیلی راحت و سریع بود. قیمت‌گذاری عالی بود و خیلی زود پول به حسابم واریز شد. حتماً دوباره از خدماتشون استفاده می‌کنم.",
        author: "محمد احمدی",
        role: "فروشنده لپ‌تاپ",
        avatar: "م"
    },
    {
        quote: "از خریدم کاملاً راضی‌ام. گوشی که گرفتم دقیقاً همون چیزی بود که تو توضیحات نوشته بودن و گارانتی سایبان هم بهم اطمینان خاطر داد. ممنون از تیم خوبتون.",
        author: "سارا رضایی",
        role: "خریدار گوشی موبایل",
        avatar: "س"
    },
    {
        quote: "فکر نمی‌کردم بتونم کنسول بازیم رو با این قیمت خوب و به این راحتی بفروشم. کل فرایند شفاف و حرفه‌ای بود. به همه دوستام معرفیتون کردم!",
        author: "علی کریمی",
        role: "فروشنده کنسول بازی",
        avatar: "ع"
    },
];

const TestimonialCard: React.FC<typeof testimonials[0]> = ({ quote, author, role, avatar }) => (
    <div className="bg-white p-8 rounded-2xl shadow-lg relative border border-gray-100">
        <div className="absolute top-4 right-6 text-7xl text-indigo-500 opacity-10">❞</div>
        <p className="relative text-gray-600 italic mb-6 leading-loose">{quote}</p>
        <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-2xl">
                {avatar}
            </div>
            <div>
                <h4 className="font-bold text-gray-800">{author}</h4>
                <p className="text-sm text-gray-500">{role}</p>
            </div>
        </div>
    </div>
);

const Testimonials: React.FC = () => {
    return (
        <section id="testimonials" className="py-20 bg-gray-50">
            <div className="container mx-auto px-5">
                <div className="text-center mb-12">
                    <h2 className="text-4xl md:text-5xl font-extrabold mb-4 bg-gradient-to-r from-indigo-500 to-purple-600 bg-clip-text text-transparent">صدای مشتریان ما</h2>
                    <p className="text-lg text-gray-600 max-w-2xl mx-auto">اعتماد شما بزرگترین سرمایه ماست. نظرات برخی از مشتریان عزیز سایبان را بخوانید.</p>
                </div>
                <div className="grid lg:grid-cols-3 gap-8">
                    {testimonials.map((testimonial, index) => (
                        <TestimonialCard key={index} {...testimonial} />
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Testimonials;
