import React from 'react';

interface HeroProps {
    onSellClick: () => void;
}

const Hero: React.FC<HeroProps> = ({ onSellClick }) => {
    return (
        <section id="home" className="relative h-screen flex items-center justify-center text-center text-white bg-gradient-to-br from-indigo-600 to-purple-700 overflow-hidden">
             <div className="absolute inset-0 bg-[url('data:image/svg+xml,<svg_xmlns=%22http://www.w3.org/2000/svg%22_viewBox=%220_0_1000_1000%22><defs><pattern_id=%22grid%22_width=%2250%22_height=%2250%22_patternUnits=%22userSpaceOnUse%22><path_d=%22M_50_0_L_0_0_0_50%22_fill=%22none%22_stroke=%22rgba(255,255,255,0.1)%22_stroke-width=%221%22/></pattern></defs><rect_width=%22100%22_height=%22100%22_fill=%22url(%23grid)%22/></svg>')] opacity-50"></div>

            <div className="absolute inset-0 z-0">
                <div className="absolute top-1/4 left-1/12 w-20 h-20 bg-white/10 rounded-full animate-float"></div>
                <div className="absolute top-2/3 right-1/12 w-16 h-16 bg-white/10 rounded-full animate-float animation-delay-[-2s]"></div>
                <div className="absolute top-1/3 right-1/3 w-10 h-10 bg-white/10 rounded-full animate-float animation-delay-[-4s]"></div>
            </div>

            <div className="z-10 max-w-4xl px-4 animate-fade-in-up">
                <h1 className="text-5xl md:text-7xl font-extrabold mb-4 text-shadow-lg">
                    Pre-owned سایبان
                </h1>
                <p className="text-xl md:text-2xl mb-8 opacity-90 max-w-2xl mx-auto">
                    بهترین مکان برای خرید و فروش امانتی کالاهای دست دوم با کیفیت. با گارانتی، قیمت مناسب و خدمات عالی.
                </p>
                <div className="flex justify-center gap-4 md:gap-6 flex-wrap">
                    <button onClick={onSellClick} className="px-8 py-4 bg-gradient-to-r from-pink-500 to-orange-500 text-white rounded-full font-semibold text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300">
                        می‌خواهم بفروشم
                    </button>
                     {/* FIX: Completed the component which was truncated, causing invalid JSX and a missing default export. */}
                     <a href="#register" className="px-8 py-4 bg-white/20 backdrop-blur-sm text-white rounded-full font-semibold text-lg shadow-lg hover:bg-white/30 transform hover:-translate-y-1 transition-all duration-300">
                        می‌خواهم بخرم
                    </a>
                </div>
            </div>
        </section>
    );
};

export default Hero;
