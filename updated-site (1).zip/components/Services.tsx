
import React from 'react';

const services = [
    {
        icon: "🛡️",
        title: "گارانتی معتبر",
        description: "تمام کالاهای ما با گارانتی سایبان عرضه می‌شوند تا خریدی با اطمینان کامل داشته باشید."
    },
    {
        icon: "💰",
        title: "قیمت‌گذاری منصفانه",
        description: "کارشناسان ما کالای شما را با بهترین و منصفانه‌ترین قیمت ممکن ارزش‌گذاری می‌کنند."
    },
    {
        icon: "✅",
        title: "فروش آسان و سریع",
        description: "فرایند فروش را به ما بسپارید. از بازاریابی تا فروش و ارسال، همه چیز با ماست."
    },
    {
        icon: "💻",
        title: "کارشناسی تخصصی",
        description: "هر کالا قبل از فروش به طور کامل توسط متخصصین ما بررسی و تست می‌شود تا از سلامت آن مطمئن شویم."
    },
];

const ServiceCard: React.FC<{ icon: string, title: string, description: string }> = ({ icon, title, description }) => (
    <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 text-center border border-gray-100">
        <div className="text-5xl mb-4">{icon}</div>
        <h3 className="text-2xl font-bold mb-3 text-gray-800">{title}</h3>
        <p className="text-gray-600 leading-relaxed">{description}</p>
    </div>
);

const Services: React.FC = () => {
    return (
        <section id="services" className="py-20 bg-white">
            <div className="container mx-auto px-5">
                <div className="text-center mb-12">
                    <h2 className="text-4xl md:text-5xl font-extrabold mb-4 bg-gradient-to-r from-indigo-500 to-purple-600 bg-clip-text text-transparent">خدمات ما</h2>
                    <p className="text-lg text-gray-600 max-w-2xl mx-auto">ما در سایبان تلاش می‌کنیم تا بهترین تجربه خرید و فروش کالای دست دوم را برای شما فراهم کنیم.</p>
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
                    {services.map((service, index) => (
                        <ServiceCard key={index} {...service} />
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Services;
