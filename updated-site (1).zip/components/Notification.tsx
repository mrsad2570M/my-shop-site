
import React, { useEffect, useState } from 'react';
import { NotificationType } from '../types';

interface NotificationProps {
    message: string;
    type: NotificationType;
    onClose: () => void;
}

const Notification: React.FC<NotificationProps> = ({ message, type, onClose }) => {
    const [isVisible, setIsVisible] = useState(false);

    useEffect(() => {
        setIsVisible(true); // Trigger fade in
        const timer = setTimeout(() => {
            setIsVisible(false);
            setTimeout(onClose, 300); // Allow fade out animation to finish
        }, 4700);

        return () => clearTimeout(timer);
    }, [onClose]);

    const bgColor = type === NotificationType.Success ? 'bg-green-500' : 'bg-red-500';

    return (
        <div 
            className={`fixed top-24 right-5 p-4 rounded-lg shadow-xl text-white font-semibold transition-transform duration-300 ease-in-out ${bgColor} ${isVisible ? 'translate-x-0' : 'translate-x-[calc(100%+20px)]'}`}
        >
            {message}
        </div>
    );
};

export default Notification;
