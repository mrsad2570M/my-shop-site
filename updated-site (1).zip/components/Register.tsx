import React, { useState, useEffect } from 'react';
import { NotificationType } from '../types';
import { UploadCloudIcon } from './Icons';

interface FormProps {
    showNotification: (message: string, type: NotificationType) => void;
    onShowTerms: () => void;
}

const SellForm: React.FC<FormProps> = ({ showNotification, onShowTerms }) => {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [productImage, setProductImage] = useState<File | null>(null);
    const [imagePreview, setImagePreview] = useState<string | null>(null);
    const [formData, setFormData] = useState({
        name: '',
        phone: '',
        email: '',
        productName: '',
        description: '',
        terms: false,
    });
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [touched, setTouched] = useState<Record<string, boolean>>({});

    const handleTermsClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
        e.preventDefault();
        onShowTerms();
    };

    useEffect(() => {
        validateForm();
    }, [formData]);

    const validateForm = () => {
        const newErrors: Record<string, string> = {};
        if (!formData.name) newErrors.name = 'نام و نام خانوادگی الزامی است.';
        if (!formData.phone) {
            newErrors.phone = 'شماره تماس الزامی است.';
        } else if (!/^09\d{9}$/.test(formData.phone)) {
            newErrors.phone = 'فرمت شماره تماس صحیح نیست (مثال: 09123456789).';
        }
        if (!formData.email) {
            newErrors.email = 'ایمیل الزامی است.';
        } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
            newErrors.email = 'فرمت ایمیل صحیح نیست.';
        }
        if (!formData.productName) newErrors.productName = 'نام کالا الزامی است.';
        if (!formData.description) newErrors.description = 'توضیحات کالا الزامی است.';
        if (!formData.terms) newErrors.terms = 'شما باید با شرایط و قوانین موافقت کنید.';
        setErrors(newErrors);
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value, type } = e.target;
        const checked = (e.target as HTMLInputElement).checked;
        setFormData(prev => ({
            ...prev,
            [name]: type === 'checkbox' ? checked : value,
        }));
    };

    const handleBlur = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name } = e.target;
        setTouched(prev => ({ ...prev, [name]: true }));
        validateForm();
    };

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setProductImage(file);
            const reader = new FileReader();
            reader.onloadend = () => {
                setImagePreview(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleRemoveImage = () => {
        setProductImage(null);
        setImagePreview(null);
        const fileInput = document.getElementById('product-image') as HTMLInputElement;
        if (fileInput) {
            fileInput.value = '';
        }
    };
    
    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setIsSubmitting(true);
        const formDataToSend = new FormData();
        formDataToSend.append('_subject', 'درخواست جدید فروش کالا در سایبان!');
        formDataToSend.append('نام فروشنده', formData.name);
        formDataToSend.append('شماره تماس', formData.phone);
        formDataToSend.append('ایمیل', formData.email);
        formDataToSend.append('نام کالا', formData.productName);
        formDataToSend.append('توضیحات کالا', formData.description);
        formDataToSend.append('پذیرش شرایط', formData.terms ? 'پذیرفته شد' : 'پذیرفته نشد');
        if (productImage) {
            formDataToSend.append('attachment', productImage);
        }

        try {
            const response = await fetch('https://formsubmit.co/ajax/mrsad2570@gmail.com', {
                method: 'POST',
                headers: { 'Accept': 'application/json' },
                body: formDataToSend,
            });

            if (response.ok) {
                showNotification("اطلاعات کالا با موفقیت به ایمیل ارسال شد.", NotificationType.Success);
                e.currentTarget.reset();
                setFormData({ name: '', phone: '', email: '', productName: '', description: '', terms: false });
                setTouched({});
                handleRemoveImage();
            } else {
                throw new Error('Network response was not ok.');
            }
        } catch (error) {
            console.error('There was a problem with the fetch operation:', error);
            showNotification("خطایی در ارسال فرم رخ داد. لطفا دوباره تلاش کنید.", NotificationType.Error);
        } finally {
            setIsSubmitting(false);
        }
    };
    
    const isFormInvalid = Object.keys(errors).length > 0;

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            <input type="hidden" name="_subject" value="درخواست جدید فروش کالا در سایبان!" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="seller-name" className="block mb-2 font-semibold text-gray-700">نام و نام خانوادگی</label>
                    <input type="text" id="seller-name" name="name" value={formData.name} onChange={handleChange} onBlur={handleBlur} required className={`w-full px-4 py-3 border-2 rounded-lg transition-all duration-300 focus:ring-2 focus:ring-indigo-300 focus:border-indigo-500 ${touched.name && errors.name ? 'border-red-500' : 'border-gray-200'}`} />
                    {touched.name && errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
                </div>
                <div>
                    <label htmlFor="seller-phone" className="block mb-2 font-semibold text-gray-700">شماره تماس</label>
                    <input type="tel" id="seller-phone" name="phone" value={formData.phone} onChange={handleChange} onBlur={handleBlur} required className={`w-full px-4 py-3 border-2 rounded-lg transition-all duration-300 focus:ring-2 focus:ring-indigo-300 focus:border-indigo-500 ${touched.phone && errors.phone ? 'border-red-500' : 'border-gray-200'}`} />
                    {touched.phone && errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
                </div>
                <div className="md:col-span-2">
                    <label htmlFor="seller-email" className="block mb-2 font-semibold text-gray-700">ایمیل</label>
                    <input type="email" id="seller-email" name="email" value={formData.email} onChange={handleChange} onBlur={handleBlur} required className={`w-full px-4 py-3 border-2 rounded-lg transition-all duration-300 focus:ring-2 focus:ring-indigo-300 focus:border-indigo-500 ${touched.email && errors.email ? 'border-red-500' : 'border-gray-200'}`} />
                    {touched.email && errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
                </div>
            </div>
            <div>
                <label htmlFor="product-name" className="block mb-2 font-semibold text-gray-700">نام کالا</label>
                <input type="text" id="product-name" name="productName" value={formData.productName} onChange={handleChange} onBlur={handleBlur} required className={`w-full px-4 py-3 border-2 rounded-lg transition-all duration-300 focus:ring-2 focus:ring-indigo-300 focus:border-indigo-500 ${touched.productName && errors.productName ? 'border-red-500' : 'border-gray-200'}`} />
                {touched.productName && errors.productName && <p className="text-red-500 text-sm mt-1">{errors.productName}</p>}
            </div>
            <div>
                <label className="block mb-2 font-semibold text-gray-700">عکس کالا (اختیاری)</label>
                {!imagePreview ? (
                    <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg">
                        <div className="space-y-1 text-center">
                            <UploadCloudIcon />
                            <div className="flex text-sm text-gray-600">
                                <label htmlFor="product-image" className="relative cursor-pointer bg-white rounded-md font-medium text-indigo-600 hover:text-indigo-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500">
                                    <span>یک فایل را بارگذاری کنید</span>
                                    <input id="product-image" name="attachment" type="file" className="sr-only" onChange={handleImageChange} accept="image/png, image/jpeg, image/webp" />
                                </label>
                                <p className="pr-1">یا اینجا بکشید و رها کنید</p>
                            </div>
                            <p className="text-xs text-gray-500">PNG, JPG, WEBP</p>
                        </div>
                    </div>
                ) : (
                    <div className="relative mt-2">
                        <img src={imagePreview} alt="پیش‌نمایش کالا" className="w-full h-auto max-h-80 object-contain rounded-lg border border-gray-300 p-1" />
                        <button 
                            type="button" 
                            onClick={handleRemoveImage} 
                            className="absolute top-2 right-2 bg-red-600 text-white rounded-full p-1.5 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-colors"
                            aria-label="حذف عکس"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>
                )}
            </div>
            <div>
                <label htmlFor="product-description" className="block mb-2 font-semibold text-gray-700">توضیحات کالا (وضعیت، لوازم جانبی و...)</label>
                <textarea id="product-description" name="description" rows={4} value={formData.description} onChange={handleChange} onBlur={handleBlur} required className={`w-full px-4 py-3 border-2 rounded-lg transition-all duration-300 focus:ring-2 focus:ring-indigo-300 focus:border-indigo-500 ${touched.description && errors.description ? 'border-red-500' : 'border-gray-200'}`}></textarea>
                {touched.description && errors.description && <p className="text-red-500 text-sm mt-1">{errors.description}</p>}
            </div>
            <div className="flex flex-col">
                <div className="flex items-center space-x-2 space-x-reverse">
                    <input type="checkbox" id="sell-terms" name="terms" checked={formData.terms} onChange={handleChange} onBlur={handleBlur} required className="w-auto" />
                    <label htmlFor="sell-terms" className="text-sm">با <a href="#" onClick={handleTermsClick} className="text-indigo-600">شرایط و قوانین</a> موافقم.</label>
                </div>
                {touched.terms && errors.terms && <p className="text-red-500 text-sm mt-1">{errors.terms}</p>}
            </div>
            <button type="submit" disabled={isSubmitting || isFormInvalid} className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold py-4 px-4 rounded-xl hover:opacity-90 transition-opacity duration-300 text-lg disabled:opacity-50 disabled:cursor-not-allowed">
                {isSubmitting ? 'در حال ارسال...' : 'ثبت درخواست فروش'}
            </button>
        </form>
    );
}

const BuyForm: React.FC<FormProps> = ({ showNotification, onShowTerms }) => {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [formData, setFormData] = useState({
        name: '',
        phone: '',
        productName: '',
        budget: '',
        terms: false,
    });
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [touched, setTouched] = useState<Record<string, boolean>>({});
    
    useEffect(() => {
        validateForm();
    }, [formData]);

    const validateForm = () => {
        const newErrors: Record<string, string> = {};
        if (!formData.name) newErrors.name = 'نام و نام خانوادگی الزامی است.';
        if (!formData.phone) {
            newErrors.phone = 'شماره تماس الزامی است.';
        } else if (!/^09\d{9}$/.test(formData.phone)) {
            newErrors.phone = 'فرمت شماره تماس صحیح نیست.';
        }
        if (!formData.productName) newErrors.productName = 'نام کالای مورد نظر الزامی است.';
        if (!formData.budget) {
            newErrors.budget = 'بودجه الزامی است.';
        } else if (isNaN(Number(formData.budget))) {
            newErrors.budget = 'بودجه باید یک عدد باشد.';
        }
        if (!formData.terms) newErrors.terms = 'شما باید با شرایط و قوانین موافقت کنید.';
        setErrors(newErrors);
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value, type, checked } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: type === 'checkbox' ? checked : value,
        }));
    };

    const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
        const { name } = e.target;
        setTouched(prev => ({ ...prev, [name]: true }));
        validateForm();
    };

    const handleTermsClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
        e.preventDefault();
        onShowTerms();
    };

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setIsSubmitting(true);
        const data = {
            '_subject': 'درخواست جدید خرید کالا در سایبان!',
            'نام خریدار': formData.name,
            'شماره تماس خریدار': formData.phone,
            'کالای مورد نظر': formData.productName,
            'بودجه': formData.budget,
            'پذیرش شرایط خرید': formData.terms ? 'پذیرفته شد' : 'پذیرفته نشد'
        };

        try {
            const response = await fetch('https://formsubmit.co/ajax/mrsad2570@gmail.com', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                },
                body: JSON.stringify(data),
            });

            if (response.ok) {
                showNotification("درخواست خرید شما با موفقیت ارسال شد.", NotificationType.Success);
                e.currentTarget.reset();
                setFormData({ name: '', phone: '', productName: '', budget: '', terms: false });
                setTouched({});
            } else {
                throw new Error('Network response was not ok.');
            }
        } catch (error) {
            console.error('There was a problem with the fetch operation:', error);
            showNotification("خطایی در ارسال فرم رخ داد. لطفا دوباره تلاش کنید.", NotificationType.Error);
        } finally {
            setIsSubmitting(false);
        }
    };
    
    const isFormInvalid = Object.keys(errors).length > 0;
    
    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            <input type="hidden" name="_subject" value="درخواست جدید خرید کالا در سایبان!" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="buyer-name" className="block mb-2 font-semibold text-gray-700">نام و نام خانوادگی</label>
                    <input type="text" id="buyer-name" name="name" value={formData.name} onChange={handleChange} onBlur={handleBlur} required className={`w-full px-4 py-3 border-2 rounded-lg transition-all duration-300 focus:ring-2 focus:ring-indigo-300 focus:border-indigo-500 ${touched.name && errors.name ? 'border-red-500' : 'border-gray-200'}`} />
                    {touched.name && errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
                </div>
                <div>
                    <label htmlFor="buyer-phone" className="block mb-2 font-semibold text-gray-700">شماره تماس</label>
                    <input type="tel" id="buyer-phone" name="phone" value={formData.phone} onChange={handleChange} onBlur={handleBlur} required className={`w-full px-4 py-3 border-2 rounded-lg transition-all duration-300 focus:ring-2 focus:ring-indigo-300 focus:border-indigo-500 ${touched.phone && errors.phone ? 'border-red-500' : 'border-gray-200'}`} />
                    {touched.phone && errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
                </div>
            </div>
            <div>
                <label htmlFor="buy-product-name" className="block mb-2 font-semibold text-gray-700">کالای مورد نظر</label>
                <input type="text" id="buy-product-name" name="productName" value={formData.productName} onChange={handleChange} onBlur={handleBlur} placeholder="مثال: لپ‌تاپ Macbook Air M1" required className={`w-full px-4 py-3 border-2 rounded-lg transition-all duration-300 focus:ring-2 focus:ring-indigo-300 focus:border-indigo-500 ${touched.productName && errors.productName ? 'border-red-500' : 'border-gray-200'}`} />
                {touched.productName && errors.productName && <p className="text-red-500 text-sm mt-1">{errors.productName}</p>}
            </div>
            <div>
                <label htmlFor="budget" className="block mb-2 font-semibold text-gray-700">بودجه (تومان)</label>
                <input type="text" id="budget" name="budget" value={formData.budget} onChange={handleChange} onBlur={handleBlur} required className={`w-full px-4 py-3 border-2 rounded-lg transition-all duration-300 focus:ring-2 focus:ring-indigo-300 focus:border-indigo-500 ${touched.budget && errors.budget ? 'border-red-500' : 'border-gray-200'}`} />
                {touched.budget && errors.budget && <p className="text-red-500 text-sm mt-1">{errors.budget}</p>}
            </div>
            <div className="flex flex-col">
                <div className="flex items-center space-x-2 space-x-reverse">
                    <input type="checkbox" id="buy-terms" name="terms" checked={formData.terms} onChange={handleChange} onBlur={handleBlur} required className="w-auto"/>
                    <label htmlFor="buy-terms" className="text-sm">با <a href="#" onClick={handleTermsClick} className="text-indigo-600">شرایط و قوانین</a> موافقم.</label>
                </div>
                {touched.terms && errors.terms && <p className="text-red-500 text-sm mt-1">{errors.terms}</p>}
            </div>
            <button type="submit" disabled={isSubmitting || isFormInvalid} className="w-full bg-gradient-to-r from-pink-500 to-orange-500 text-white font-bold py-4 px-4 rounded-xl hover:opacity-90 transition-opacity duration-300 text-lg disabled:opacity-50 disabled:cursor-not-allowed">
                {isSubmitting ? 'در حال ارسال...' : 'ثبت درخواست خرید'}
            </button>
        </form>
    );
}

interface RegisterProps extends FormProps {
    activeTab: string;
    setActiveTab: (tab: 'sell' | 'buy') => void;
}

const Register: React.FC<RegisterProps> = ({ showNotification, activeTab, setActiveTab, onShowTerms }) => {
    return (
        <section id="register" className="py-20 bg-gray-50">
            <div className="container mx-auto px-5">
                <div className="text-center mb-12">
                    <h2 className="text-4xl md:text-5xl font-extrabold mb-4 bg-gradient-to-r from-indigo-500 to-purple-600 bg-clip-text text-transparent">کالای خود را ثبت کنید</h2>
                    <p className="text-lg text-gray-600 max-w-2xl mx-auto">چه قصد فروش کالای دست دوم خود را دارید و چه به دنبال خرید هستید، ما اینجاییم تا به شما کمک کنیم.</p>
                </div>
                <div className="grid lg:grid-cols-3 gap-12 items-start">
                    <div className="lg:col-span-2 bg-white rounded-2xl shadow-xl overflow-hidden">
                        <div className="flex">
                            <button onClick={() => setActiveTab('sell')} className={`flex-1 py-4 text-lg font-semibold border-b-4 transition-colors duration-300 ${activeTab === 'sell' ? 'text-indigo-600 border-indigo-600 bg-white' : 'text-gray-500 border-transparent hover:bg-gray-100'}`}>می‌خواهم بفروشم</button>
                            <button onClick={() => setActiveTab('buy')} className={`flex-1 py-4 text-lg font-semibold border-b-4 transition-colors duration-300 ${activeTab === 'buy' ? 'text-indigo-600 border-indigo-600 bg-white' : 'text-gray-500 border-transparent hover:bg-gray-100'}`}>می‌خواهم بخرم</button>
                        </div>
                        <div className="p-8">
                            <div className={activeTab === 'sell' ? 'block' : 'hidden'}><SellForm showNotification={showNotification} onShowTerms={onShowTerms} /></div>
                            <div className={activeTab === 'buy' ? 'block' : 'hidden'}><BuyForm showNotification={showNotification} onShowTerms={onShowTerms} /></div>
                        </div>
                    </div>
                    <div className="space-y-6">
                        <div className="bg-white p-6 rounded-2xl shadow-lg">
                            <h3 className="text-xl font-bold mb-4">چرا فروش امانتی؟</h3>
                             <p className="text-gray-600">
                                فروش امانتی یعنی کالای شما با بهترین قیمت، بدون دردسر و با گارانتی سایبان به فروش می‌رسد. ما تمام مراحل را برای شما انجام می‌دهیم.
                            </p>
                        </div>
                        <div className="bg-white p-6 rounded-2xl shadow-lg">
                            <h3 className="text-xl font-bold mb-4">مراحل فروش</h3>
                            <div className="space-y-4">
                                <div className="flex items-center gap-4">
                                    <div className="w-8 h-8 flex-shrink-0 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-full flex items-center justify-center font-bold">۱</div>
                                    <span className="font-medium">ثبت فرم و تماس ما</span>
                                </div>
                                <div className="flex items-center gap-4">
                                    <div className="w-8 h-8 flex-shrink-0 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-full flex items-center justify-center font-bold">۲</div>
                                    <span className="font-medium">کارشناسی و قیمت‌گذاری</span>
                                </div>
                                <div className="flex items-center gap-4">
                                    <div className="w-8 h-8 flex-shrink-0 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-full flex items-center justify-center font-bold">۳</div>
                                    <span className="font-medium">فروش کالا و تسویه حساب</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Register;