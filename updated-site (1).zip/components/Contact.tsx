import React, { useState } from 'react';
import { NotificationType } from '../types';
import { PhoneIcon, MapPinIcon, EnvelopeIcon } from './Icons';

interface ContactProps {
    showNotification: (message: string, type: NotificationType) => void;
}

const Contact: React.FC<ContactProps> = ({ showNotification }) => {
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setIsSubmitting(true);
        const formData = new FormData(e.currentTarget);
        const data = Object.fromEntries(formData.entries());

        try {
            const response = await fetch('https://formsubmit.co/ajax/mrsad2570@gmail.com', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(data)
            });

            if (response.ok) {
                showNotification("پیام شما با موفقیت ارسال شد. سپاسگزاریم!", NotificationType.Success);
                e.currentTarget.reset();
            } else {
                throw new Error('Network response was not ok.');
            }
        } catch (error) {
            console.error('Error submitting contact form:', error);
            showNotification("خطایی در ارسال پیام رخ داد. لطفا دوباره تلاش کنید.", NotificationType.Error);
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <section id="contact" className="py-20 bg-gradient-to-br from-indigo-600 to-purple-700 text-white">
            <div className="container mx-auto px-5">
                <div className="grid lg:grid-cols-2 gap-12 items-center">
                    <div>
                        <h2 className="text-4xl md:text-5xl font-extrabold mb-6">در تماس باشید</h2>
                        <p className="text-lg mb-8 opacity-90">
                            سوال یا پیشنهادی دارید؟ می‌خواهید در مورد کالایی مشاوره بگیرید؟ راه‌های ارتباطی ما همیشه باز است.
                        </p>
                        <ul className="space-y-6">
                            <li className="flex items-center gap-4 text-lg">
                                <MapPinIcon />
                                <span>اصفهان</span>
                            </li>
                            <li className="flex items-center gap-4 text-lg">
                                <PhoneIcon />
                                <a href="tel:+989139330651" className="hover:underline">۰۹۱۳۹۳۳۰۶۵۱</a>
                            </li>
                            <li className="flex items-center gap-4 text-lg">
                                <EnvelopeIcon className="h-6 w-6" />
                                <a href="mailto:mrsad2570@gmail.com" className="hover:underline">mrsad2570@gmail.com</a>
                            </li>
                        </ul>
                    </div>
                    <div className="bg-white/10 p-8 rounded-2xl backdrop-blur-sm">
                        <form onSubmit={handleSubmit} className="space-y-5">
                            <input type="hidden" name="_subject" value="پیام جدید از فرم تماس سایبان!" />
                             <input type="text" name="name" placeholder="نام شما" required className="w-full px-4 py-3 bg-white/90 text-gray-800 rounded-lg border-none placeholder-gray-500 focus:ring-2 focus:ring-pink-400 focus:outline-none transition" />
                             <input type="email" name="email" placeholder="ایمیل شما" required className="w-full px-4 py-3 bg-white/90 text-gray-800 rounded-lg border-none placeholder-gray-500 focus:ring-2 focus:ring-pink-400 focus:outline-none transition" />
                             <textarea name="message" placeholder="پیام شما..." rows={5} required className="w-full px-4 py-3 bg-white/90 text-gray-800 rounded-lg border-none placeholder-gray-500 focus:ring-2 focus:ring-pink-400 focus:outline-none transition"></textarea>
                             <button type="submit" disabled={isSubmitting} className="w-full bg-gradient-to-r from-pink-500 to-orange-500 text-white font-bold py-4 px-4 rounded-xl hover:opacity-90 transition-opacity duration-300 text-lg disabled:opacity-50 disabled:cursor-not-allowed">
                                {isSubmitting ? 'در حال ارسال...' : 'ارسال پیام'}
                             </button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Contact;