import React from 'react';
import { InstagramIcon, MapPinIcon, EnvelopeIcon } from './Icons';

interface FooterProps {
    onShowTerms: () => void;
}

const Footer: React.FC<FooterProps> = ({ onShowTerms }) => {
    const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
        e.preventDefault();
        const href = e.currentTarget.getAttribute('href');
        if (href && href.startsWith('#') && href.length > 1) {
            const targetElement = document.querySelector(href);
            if (targetElement) {
                targetElement.scrollIntoView({ behavior: 'smooth' });
            }
        }
    };

    const handleTermsClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
        e.preventDefault();
        onShowTerms();
    };

    return (
        <footer className="bg-gray-900 text-gray-300 py-12">
            <div className="container mx-auto px-5">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
                    <div>
                        <h3 className="text-xl font-bold text-white mb-4">🏪 سایبان</h3>
                        <p className="text-sm">پلتفرم امن خرید و فروش امانتی کالای دست دوم.</p>
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold text-white mb-4">لینک‌های سریع</h3>
                        <ul>
                            <li className="mb-2"><a href="#services" onClick={handleNavClick} className="text-gray-400 hover:text-white transition-colors duration-300">خدمات</a></li>
                            <li className="mb-2"><a href="#register" onClick={handleNavClick} className="text-gray-400 hover:text-white transition-colors duration-300">ثبت کالا</a></li>
                            <li className="mb-2"><a href="#testimonials" onClick={handleNavClick} className="text-gray-400 hover:text-white transition-colors duration-300">نظرات</a></li>
                        </ul>
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold text-white mb-4">پشتیبانی</h3>
                        <ul>
                            <li className="mb-2"><a href="#contact" onClick={handleNavClick} className="text-gray-400 hover:text-white transition-colors duration-300">تماس با ما</a></li>
                            <li className="mb-2"><a href="#" className="text-gray-400 hover:text-white transition-colors duration-300">سوالات متداول</a></li>
                            <li className="mb-2"><a href="#" onClick={handleTermsClick} className="text-gray-400 hover:text-white transition-colors duration-300">قوانین و مقررات</a></li>
                        </ul>
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold text-white mb-4">ارتباط با ما</h3>
                         <ul className="space-y-3">
                            <li className="flex items-center gap-2 text-sm text-gray-400">
                                <MapPinIcon />
                                <span>اصفهان</span>
                            </li>
                            <li>
                                <a href="mailto:mrsad2570@gmail.com" className="text-sm text-gray-400 hover:text-white transition-colors duration-300 flex items-center gap-2">
                                    <EnvelopeIcon className="h-6 w-6" />
                                    <span>mrsad2570@gmail.com</span>
                                </a>
                            </li>
                             <li>
                                <a href="https://www.instagram.com/preowned_sayeban/" target="_blank" rel="noopener noreferrer" className="text-sm text-gray-400 hover:text-white transition-colors duration-300 flex items-center gap-2">
                                    <InstagramIcon />
                                    <span>اینستاگرام ما</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div className="border-t border-gray-700 pt-6 text-center text-gray-500 text-sm">
                    <p>&copy; {new Date().getFullYear()} Pre-owned سایبان. تمام حقوق محفوظ است.</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;